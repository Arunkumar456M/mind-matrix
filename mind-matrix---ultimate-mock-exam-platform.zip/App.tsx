
import React, { useState, useEffect } from 'react';
import { AppState, ExamData, UserResponse, Question, User } from './types.ts';
import { getExamMetadata, generateQuestionBatch, generateExamFromBase64 } from './services/geminiService.ts';
import HomeView from './components/HomeView.tsx';
import MockTestView from './components/MockTestView.tsx';
import ResultView from './components/ResultView.tsx';
import LoadingOverlay from './components/LoadingOverlay.tsx';
import LoginView from './components/LoginView.tsx';

const App: React.FC = () => {
  const [appState, setAppState] = useState<AppState>(AppState.LOGIN);
  const [user, setUser] = useState<User | null>(null);
  const [examData, setExamData] = useState<ExamData | null>(null);
  const [userResponses, setUserResponses] = useState<UserResponse[]>([]);
  const [loadingStep, setLoadingStep] = useState<string>('');
  const [progress, setProgress] = useState(0);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('mindmatrix_user');
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        setUser(parsed);
        setAppState(AppState.HOME);
      } catch (e) {
        console.error("Failed to restore user session");
      }
    }
  }, []);

  const handleLogin = (name: string, email: string) => {
    const newUser = { name, email };
    setUser(newUser);
    localStorage.setItem('mindmatrix_user', JSON.stringify(newUser));
    setAppState(AppState.HOME);
  };

  const handleUpdateUser = (updatedUser: User) => {
    setUser(updatedUser);
    localStorage.setItem('mindmatrix_user', JSON.stringify(updatedUser));
  };

  const handleLogout = () => {
    localStorage.removeItem('mindmatrix_user');
    setUser(null);
    setAppState(AppState.LOGIN);
    setExamData(null);
    setUserResponses([]);
  };

  const wait = (ms: number) => new Promise(r => setTimeout(r, ms));

  const startExamByName = async (name: string, subject: string, difficulty: string) => {
    setIsLoading(true);
    setError(null);
    setProgress(0);
    setLoadingStep(`Analyzing ${name} pattern for ${subject}...`);
    
    await wait(50);

    try {
      const metadata = await getExamMetadata(name, subject, difficulty);
      setProgress(15);

      let allQuestions: Question[] = [];
      const batchSize = 25;
      const totalSteps = Math.ceil(metadata.totalQuestions / batchSize);

      for (let i = 0; i < totalSteps; i++) {
        setLoadingStep(`Generating ${subject} batch ${i + 1} of ${totalSteps}...`);
        const result = await generateQuestionBatch(name, subject, metadata, i * batchSize, batchSize, allQuestions.length);
        allQuestions = [...allQuestions, ...result.questions];
        setProgress(15 + ((i + 1) / totalSteps) * 85);
        await wait(20);
      }

      const finalExam: ExamData = { metadata, questions: allQuestions };
      setExamData(finalExam);
      initializeResponses(finalExam);
      setAppState(AppState.TEST);
    } catch (err) {
      console.error(err);
      setError("Exam generation failed. This might be due to API constraints or connectivity. Please try again or simplify the subject.");
    } finally {
      setIsLoading(false);
    }
  };

  const startExamFromFile = async (file: File) => {
    setIsLoading(true);
    setError(null);
    setProgress(5);
    setLoadingStep("Processing document content...");
    
    await wait(50);

    try {
      const reader = new FileReader();
      reader.onload = async () => {
        try {
          const base64 = (reader.result as string).split(',')[1];
          const data = await generateExamFromBase64(base64, file.type);
          setExamData(data);
          initializeResponses(data);
          setAppState(AppState.TEST);
        } catch (innerErr) {
          setError("Failed to generate test from this document.");
          console.error(innerErr);
        } finally {
          setIsLoading(false);
        }
      };
      reader.readAsDataURL(file);
    } catch (err) {
      setError("File read error.");
      setIsLoading(false);
      console.error(err);
    }
  };

  const initializeResponses = (data: ExamData) => {
    const initial = data.questions.map(q => ({
      questionId: q.id,
      selectedOption: null,
      isMarkedForReview: false,
      status: 'not-visited' as const
    }));
    setUserResponses(initial);
  };

  const handleFinishExam = (finalResponses: UserResponse[]) => {
    setUserResponses(finalResponses);
    setAppState(AppState.RESULTS);
  };

  const resetToHome = () => {
    setAppState(AppState.HOME);
    setExamData(null);
    setUserResponses([]);
    setProgress(0);
    setLoadingStep('');
  };

  return (
    <div className="min-h-screen bg-gray-50 text-gray-900 relative">
      {appState === AppState.LOGIN && (
        <LoginView onLogin={handleLogin} />
      )}

      {appState === AppState.HOME && (
        <HomeView 
          user={user}
          onLogout={handleLogout}
          onUpdateUser={handleUpdateUser}
          onStartByName={startExamByName} 
          onStartByFile={startExamFromFile} 
          error={error}
        />
      )}

      {appState === AppState.TEST && examData && (
        <MockTestView 
          examData={examData} 
          initialResponses={userResponses}
          onFinish={handleFinishExam}
        />
      )}

      {appState === AppState.RESULTS && examData && (
        <ResultView 
          examData={examData} 
          userResponses={userResponses} 
          onRestart={resetToHome}
          userName={user?.name || "Anonymous User"}
          // Fixed: Added the missing userEmail property required by ResultViewProps
          userEmail={user?.email || "anonymous@matrix.io"}
        />
      )}

      {isLoading && <LoadingOverlay message={loadingStep} progress={progress} />}
    </div>
  );
};

export default App;
