
import React from 'react';

export const BrainLogo = ({ className = "w-full h-full" }: { className?: string }) => (
  <svg viewBox="0 0 200 180" className={`${className} drop-shadow-[0_0_25px_rgba(79,70,229,0.5)]`}>
    <defs>
      <radialGradient id="brainGlow" cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#4f46e5" stopOpacity="0.3" />
        <stop offset="100%" stopColor="#4f46e5" stopOpacity="0" />
      </radialGradient>
    </defs>
    <circle cx="100" cy="85" r="85" fill="url(#brainGlow)" />
    
    <g stroke="#ffffff" strokeWidth="1.2" strokeLinecap="round" opacity="0.9">
      <line x1="100" y1="40" x2="135" y2="35" stroke="#ffffff" />
      <line x1="135" y1="35" x2="165" y2="65" stroke="#ffffff" />
      <line x1="165" y1="65" x2="160" y2="105" stroke="#ffffff" />
      <line x1="160" y1="105" x2="130" y2="135" stroke="#ffffff" />
      <line x1="130" y1="135" x2="90" y2="140" stroke="#ffffff" />
      <line x1="90" y1="140" x2="60" y2="115" stroke="#ffffff" />
      <line x1="60" y1="115" x2="55" y2="75" stroke="#ffffff" />
      <line x1="55" y1="75" x2="85" y2="45" stroke="#ffffff" />
      <line x1="85" y1="45" x2="100" y2="40" stroke="#ffffff" />

      <line x1="105" y1="80" x2="100" y2="40" stroke="#ffffff" strokeWidth="2.5" />
      <line x1="105" y1="80" x2="135" y2="35" stroke="#bef264" />
      <line x1="105" y1="80" x2="165" y2="65" stroke="#60a5fa" />
      <line x1="105" y1="80" x2="160" y2="105" stroke="#3b82f6" />
      <line x1="105" y1="80" x2="130" y2="135" stroke="#3b82f6" />
      <line x1="105" y1="80" x2="90" y2="140" stroke="#60a5fa" />
      <line x1="105" y1="80" x2="60" y2="115" stroke="#93c5fd" />
      <line x1="105" y1="80" x2="55" y2="75" stroke="#93c5fd" />
      <line x1="105" y1="80" x2="85" y2="45" stroke="#bef264" />
      
      <line x1="85" y1="45" x2="115" y2="60" stroke="#bef264" />
      <line x1="135" y1="35" x2="115" y2="60" stroke="#bef264" />
      <line x1="165" y1="65" x2="140" y2="85" stroke="#60a5fa" />
      <line x1="60" y1="115" x2="85" y2="95" stroke="#93c5fd" />
    </g>

    <g>
      <circle cx="100" cy="40" r="5" fill="#ffffff" />
      <circle cx="135" cy="35" r="4" fill="#bef264" />
      <circle cx="165" cy="65" r="6" fill="#60a5fa" />
      <circle cx="160" cy="105" r="4" fill="#3b82f6" />
      <circle cx="130" cy="135" r="5" fill="#3b82f6" />
      <circle cx="90" cy="140" r="4" fill="#60a5fa" />
      <circle cx="60" cy="115" r="6" fill="#93c5fd" />
      <circle cx="55" cy="75" r="5" fill="#3b82f6" />
      <circle cx="85" cy="45" r="4" fill="#bef264" />
      <circle cx="105" cy="80" r="8" fill="#ffffff" />
      <circle cx="115" cy="60" r="3" fill="#bef264" />
      <circle cx="140" cy="85" r="3" fill="#ffffff" />
      <circle cx="85" cy="95" r="3" fill="#ffffff" />
    </g>
  </svg>
);
