
import React, { useState, useEffect } from 'react';
import { BrainLogo } from './BrainLogo.tsx';
import { User, LeaderboardEntry } from '../types.ts';
import { Reveal } from './Reveal.tsx';
import ProfileEditModal from './ProfileEditModal.tsx';
import LeaderboardModal from './LeaderboardModal.tsx';

interface HomeViewProps {
  user: User | null;
  onLogout: () => void;
  onUpdateUser: (updatedUser: User) => void;
  onStartByName: (name: string, subject: string, difficulty: string) => void;
  onStartByFile: (file: File) => void;
  error: string | null;
}

const HISTORY_KEY = 'mindmatrix_exam_history_v1';
const LEADERBOARD_KEY = 'mindmatrix_leaderboard_v1';

interface HistoryItem {
  name: string;
  subject: string;
}

const HomeView: React.FC<HomeViewProps> = ({ user, onLogout, onUpdateUser, onStartByName, onStartByFile, error }) => {
  const [examName, setExamName] = useState('');
  const [subject, setSubject] = useState('');
  const [difficulty, setDifficulty] = useState('Medium');
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [leaderboard, setLeaderboard] = useState<LeaderboardEntry[]>([]);
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showLeaderboard, setShowLeaderboard] = useState(false);

  useEffect(() => {
    const savedHistory = localStorage.getItem(HISTORY_KEY);
    if (savedHistory) {
      try {
        setHistory(JSON.parse(savedHistory));
      } catch (e) {
        console.error("Failed to parse history", e);
      }
    }

    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    if (savedLeaderboard) {
      try {
        setLeaderboard(JSON.parse(savedLeaderboard));
      } catch (e) {
        console.error("Failed to parse leaderboard", e);
      }
    }
  }, []);

  const saveToHistory = (name: string, sub: string) => {
    const trimmedName = name.trim();
    const trimmedSub = sub.trim();
    if (!trimmedName || !trimmedSub) return;
    
    const newItem = { name: trimmedName, subject: trimmedSub };
    const filteredHistory = history.filter(h => h.name !== trimmedName || h.subject !== trimmedSub);
    const newHistory = [newItem, ...filteredHistory].slice(0, 5);
    
    setHistory(newHistory);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(newHistory));
  };

  const handleStart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!examName.trim() || !subject.trim()) return;
    saveToHistory(examName, subject);
    onStartByName(examName, subject, difficulty);
  };

  const handleHistoryClick = (item: HistoryItem) => {
    setExamName(item.name);
    setSubject(item.subject);
    onStartByName(item.name, item.subject, difficulty);
  };

  const difficulties = [
    { label: 'Easy', color: 'text-green-500', bg: 'bg-green-50', active: 'bg-green-600' },
    { label: 'Medium', color: 'text-yellow-600', bg: 'bg-yellow-50', active: 'bg-yellow-600' },
    { label: 'Hard', color: 'text-red-500', bg: 'bg-red-50', active: 'bg-red-600' }
  ];

  const getInitials = (name: string) => {
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
  };

  // User Stats Calculation
  const userEntries = leaderboard.filter(e => e.userEmail === user?.email);
  const avgAccuracy = userEntries.length 
    ? Math.round(userEntries.reduce((acc, curr) => acc + curr.percentage, 0) / userEntries.length)
    : 0;
  const topScore = userEntries.length 
    ? Math.max(...userEntries.map(e => e.percentage))
    : 0;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header / Top Nav */}
      <div className="absolute top-0 w-full z-50 px-8 py-6 flex justify-between items-center pointer-events-none">
        <div className="pointer-events-auto">
        </div>
        
        {user && (
          <div className="relative pointer-events-auto">
            <button 
              onClick={() => setShowProfileMenu(!showProfileMenu)}
              className="flex items-center gap-3 bg-white/10 backdrop-blur-md border border-white/20 p-1.5 pr-4 rounded-full hover:bg-white/20 transition-all group shadow-xl"
            >
              <div className="w-10 h-10 bg-gradient-to-br from-indigo-500 to-[#00ccff] rounded-full flex items-center justify-center text-white font-black text-xs shadow-lg">
                {getInitials(user.name)}
              </div>
              <div className="text-left hidden sm:block">
                <p className="text-[10px] font-black text-white uppercase tracking-widest leading-none mb-1">{user.name}</p>
                <p className="text-[9px] font-bold text-white/50 lowercase tracking-tighter leading-none">{user.email}</p>
              </div>
              <i className={`fas fa-chevron-down text-[10px] text-white/50 group-hover:text-white transition-transform ${showProfileMenu ? 'rotate-180' : ''}`}></i>
            </button>

            {showProfileMenu && (
              <>
                <div className="fixed inset-0 z-10" onClick={() => setShowProfileMenu(false)}></div>
                <div className="absolute right-0 mt-3 w-64 bg-white rounded-3xl shadow-2xl border border-gray-100 p-2 z-20 animate-in fade-in slide-in-from-top-2 duration-200 overflow-hidden">
                  <div className="p-4 border-b border-gray-50 mb-2">
                     <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-1">User Profile</p>
                     <p className="text-sm font-black text-gray-800 truncate">{user.name}</p>
                     <p className="text-[10px] font-medium text-gray-400 truncate">{user.email}</p>
                     {user.location && (
                       <p className="text-[9px] font-bold text-indigo-500 uppercase tracking-widest mt-1">
                        <i className="fas fa-location-dot mr-1"></i> {user.location}
                       </p>
                     )}
                  </div>
                  
                  <button 
                    onClick={() => { setShowProfileMenu(false); setShowEditModal(true); }}
                    className="w-full text-left p-4 hover:bg-indigo-50 rounded-2xl flex items-center gap-3 text-indigo-600 transition-colors group mb-1"
                  >
                    <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all">
                      <i className="fas fa-user-edit text-xs"></i>
                    </div>
                    <span className="text-xs font-black uppercase tracking-widest">Profile & Stats</span>
                  </button>

                  <button 
                    onClick={() => { setShowProfileMenu(false); setShowLeaderboard(true); }}
                    className="w-full text-left p-4 hover:bg-indigo-50 rounded-2xl flex items-center gap-3 text-indigo-600 transition-colors group mb-1"
                  >
                    <div className="w-8 h-8 rounded-xl bg-indigo-50 flex items-center justify-center group-hover:bg-indigo-600 group-hover:text-white transition-all">
                      <i className="fas fa-trophy text-xs"></i>
                    </div>
                    <span className="text-xs font-black uppercase tracking-widest">Global Ranking</span>
                  </button>

                  <button 
                    onClick={onLogout}
                    className="w-full text-left p-4 hover:bg-rose-50 rounded-2xl flex items-center gap-3 text-rose-600 transition-colors group"
                  >
                    <div className="w-8 h-8 rounded-xl bg-rose-50 flex items-center justify-center group-hover:bg-rose-600 group-hover:text-white transition-all">
                      <i className="fas fa-sign-out-alt text-xs"></i>
                    </div>
                    <span className="text-xs font-black uppercase tracking-widest">Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>
        )}
      </div>

      {/* Hero Section */}
      <div className="bg-slate-950 pt-16 pb-28 px-4 text-center relative overflow-hidden flex flex-col items-center">
        <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[700px] h-[400px] bg-indigo-600/20 blur-[130px] rounded-full"></div>
        
        <div className="relative z-10 w-full max-w-4xl flex flex-col items-center">
          <Reveal delay="delay-100" className="w-44 h-44 mb-2">
            <BrainLogo />
          </Reveal>
          
          <Reveal delay="delay-200" className="relative">
            <h1 className="text-7xl font-black tracking-tight flex items-center justify-center gap-3">
              <span className="text-white">MIND</span>
              <span className="text-[#00ccff]">MATRIX</span>
            </h1>
            <svg className="absolute -bottom-4 left-0 w-full h-4 text-white/30" viewBox="0 0 100 10" preserveAspectRatio="none">
              <path d="M0 5 Q 50 0 100 5" fill="none" stroke="currentColor" strokeWidth="0.8" />
            </svg>
          </Reveal>
          
          <Reveal delay="delay-300">
            <p className="text-xl text-slate-400 max-w-2xl mx-auto font-medium mt-12 italic">
              "The ultimate intelligent mock test generator and proctor."
            </p>
            {user?.bio && (
              <p className="mt-4 text-xs font-bold text-slate-500 max-w-lg mx-auto uppercase tracking-[0.2em] leading-relaxed">
                {user.bio}
              </p>
            )}
            
            {/* Quick Stats Dashboard */}
            <div className="mt-10 flex gap-12 justify-center">
              <div className="text-center group cursor-pointer" onClick={() => setShowEditModal(true)}>
                <p className="text-3xl font-black text-white group-hover:text-[#00ccff] transition-colors">{userEntries.length}</p>
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mt-1">Exams Taken</p>
              </div>
              <div className="text-center group cursor-pointer" onClick={() => setShowEditModal(true)}>
                <p className="text-3xl font-black text-white group-hover:text-[#00ccff] transition-colors">{avgAccuracy}%</p>
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mt-1">Avg Accuracy</p>
              </div>
              <div className="text-center group cursor-pointer" onClick={() => setShowEditModal(true)}>
                <p className="text-3xl font-black text-white group-hover:text-[#00ccff] transition-colors">{topScore}%</p>
                <p className="text-[10px] font-black text-slate-600 uppercase tracking-widest mt-1">Peak Index</p>
              </div>
            </div>
          </Reveal>
        </div>
      </div>

      <div className="max-w-4xl mx-auto -mt-14 px-4 pb-20 relative z-20">
        <div className="grid md:grid-cols-2 gap-8">
          <Reveal animation="reveal-left" delay="delay-200">
            <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 hover:border-indigo-200 transition-all duration-500 group h-full">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-indigo-50 rounded-2xl flex items-center justify-center text-indigo-600 group-hover:bg-indigo-600 group-hover:text-white transition-all duration-500">
                  <i className="fas fa-search text-xl"></i>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-gray-800 leading-none">Standard Exam</h2>
                  <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">Official Patterns</p>
                </div>
              </div>
              
              <form onSubmit={handleStart} className="space-y-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Exam Name</label>
                    <input 
                      type="text" 
                      placeholder="e.g. GATE, SSC, UPSC, Banking" 
                      className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all font-bold text-gray-700"
                      value={examName}
                      onChange={(e) => setExamName(e.target.value)}
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Subject / Branch</label>
                    <input 
                      type="text" 
                      placeholder="e.g. Electrical, Computer Science, Civil" 
                      className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all font-bold text-gray-700"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                    />
                  </div>
                </div>
                
                {history.length > 0 && (
                  <div className="pt-2">
                    <span className="text-[10px] font-black text-gray-400 uppercase tracking-widest block mb-3">Quick Resume</span>
                    <div className="flex flex-wrap gap-2">
                      {history.map((item, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => handleHistoryClick(item)}
                          className="px-4 py-2 bg-indigo-50/50 hover:bg-indigo-600 text-indigo-600 hover:text-white text-[10px] font-black rounded-xl transition-all border border-indigo-100 uppercase tracking-widest"
                        >
                          {item.name} · {item.subject}
                        </button>
                      ))}
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-3">Intensity</label>
                  <div className="grid grid-cols-3 gap-2">
                    {difficulties.map((d) => (
                      <button
                        key={d.label}
                        type="button"
                        onClick={() => setDifficulty(d.label)}
                        className={`py-3 rounded-2xl border-2 font-black text-[10px] uppercase tracking-widest transition-all ${
                          difficulty === d.label 
                            ? `${d.active} text-white border-transparent shadow-xl` 
                            : `border-gray-50 text-gray-400 hover:border-gray-200 bg-gray-50`
                        }`}
                      >
                        {d.label}
                      </button>
                    ))}
                  </div>
                </div>

                <button 
                  type="submit"
                  disabled={!examName.trim() || !subject.trim()}
                  className="w-full py-5 bg-indigo-600 text-white rounded-[1.5rem] font-black uppercase tracking-widest text-xs hover:bg-indigo-700 disabled:opacity-30 transition-all shadow-2xl shadow-indigo-200"
                >
                  Start Generating Test
                </button>
              </form>
            </div>
          </Reveal>

          <Reveal animation="reveal-right" delay="delay-400">
            <div className="bg-white p-10 rounded-[2.5rem] shadow-2xl border border-gray-100 hover:border-emerald-200 transition-all duration-500 group h-full">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-12 h-12 bg-emerald-50 rounded-2xl flex items-center justify-center text-emerald-600 group-hover:bg-emerald-600 group-hover:text-white transition-all duration-500">
                  <i className="fas fa-file-pdf text-xl"></i>
                </div>
                <div>
                  <h2 className="text-2xl font-black text-gray-800 leading-none">Custom File</h2>
                  <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">Personal Notes</p>
                </div>
              </div>
              
              <p className="text-gray-500 mb-8 font-medium">Upload your textbooks, study materials, or handwritten notes to generate a specific mock test.</p>
              
              <div className="border-[3px] border-dashed border-gray-100 rounded-3xl p-12 text-center hover:bg-emerald-50/50 hover:border-emerald-200 transition-all relative group/drop cursor-pointer">
                <input 
                  type="file" 
                  accept="application/pdf,image/*"
                  className="absolute inset-0 opacity-0 cursor-pointer"
                  onChange={(e) => e.target.files?.[0] && onStartByFile(e.target.files[0])}
                />
                <div className="space-y-4">
                  <div className="w-20 h-20 bg-emerald-50 rounded-[2rem] mx-auto flex items-center justify-center text-emerald-400 group-hover/drop:scale-110 group-hover/drop:bg-emerald-100 transition-all">
                    <i className="fas fa-cloud-upload-alt text-3xl"></i>
                  </div>
                  <div>
                    <p className="font-black text-gray-700 uppercase tracking-widest text-xs">Drop Syllabus PDF</p>
                    <p className="text-[10px] text-gray-400 font-bold mt-1">PDF, JPG, PNG · MAX 10MB</p>
                  </div>
                </div>
              </div>

              <div className="mt-12 bg-gray-50 rounded-2xl p-6 border border-gray-100">
                 <div className="flex items-start gap-4">
                    <i className="fas fa-info-circle text-gray-300 mt-1"></i>
                    <p className="text-[10px] font-bold text-gray-400 leading-relaxed uppercase tracking-wider">
                      Documents are analyzed locally. Gemini AI generates questions based on context depth.
                    </p>
                 </div>
              </div>
            </div>
          </Reveal>
        </div>

        <Reveal animation="reveal" delay="delay-300">
          <footer className="mt-20 pt-10 border-t border-gray-200 flex flex-col items-center gap-8">
            <div className="flex gap-12 grayscale opacity-30 hover:grayscale-0 hover:opacity-100 transition-all duration-700">
               <div className="flex items-center gap-3"><i className="fas fa-shield-halved text-2xl"></i> <span className="text-[10px] font-black uppercase tracking-widest">AI Proctored</span></div>
               <div className="flex items-center gap-3"><i className="fas fa-microchip text-2xl"></i> <span className="text-[10px] font-black uppercase tracking-widest">Batch Flow 2.0</span></div>
               <div className="flex items-center gap-3"><i className="fas fa-magnifying-glass-chart text-2xl"></i> <span className="text-[10px] font-black uppercase tracking-widest">Testbook Sync</span></div>
            </div>
            <p className="text-[10px] font-black text-gray-300 uppercase tracking-[0.4em]">Integrated Intelligence by Google Gemini</p>
          </footer>
        </Reveal>
      </div>

      {showEditModal && user && (
        <ProfileEditModal 
          user={user} 
          onClose={() => setShowEditModal(false)} 
          onSave={(updated) => {
            onUpdateUser(updated);
            setShowEditModal(false);
          }}
        />
      )}

      {showLeaderboard && (
        <LeaderboardModal 
          entries={leaderboard} 
          onClose={() => setShowLeaderboard(false)}
          currentUserEmail={user?.email}
        />
      )}

      {error && (
        <div className="fixed bottom-8 left-1/2 -translate-x-1/2 z-50 p-6 bg-rose-50 text-rose-600 rounded-3xl border-2 border-rose-100 flex items-center gap-4 shadow-2xl animate-in slide-in-from-bottom-10">
          <i className="fas fa-exclamation-triangle text-xl"></i>
          <p className="font-black text-sm uppercase tracking-widest">{error}</p>
        </div>
      )}
    </div>
  );
};

export default HomeView;
