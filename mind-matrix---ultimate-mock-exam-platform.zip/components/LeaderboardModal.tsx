
import React from 'react';
import { LeaderboardEntry } from '../types.ts';

interface LeaderboardModalProps {
  onClose: () => void;
  entries: LeaderboardEntry[];
  currentUserEmail?: string;
}

const LeaderboardModal: React.FC<LeaderboardModalProps> = ({ onClose, entries, currentUserEmail }) => {
  // Sort entries by percentage descending, then by score
  const sortedEntries = [...entries].sort((a, b) => b.percentage - a.percentage || b.score - a.score);

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/90 backdrop-blur-2xl animate-in fade-in duration-300">
      <div className="bg-white rounded-[3rem] w-full max-w-2xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[80vh]">
        <div className="p-10 border-b border-gray-100 bg-slate-50 flex justify-between items-center shrink-0">
          <div className="flex items-center gap-5">
            <div className="w-14 h-14 bg-indigo-600 rounded-[1.25rem] flex items-center justify-center text-white shadow-xl shadow-indigo-200">
              <i className="fas fa-trophy text-2xl"></i>
            </div>
            <div>
              <h3 className="text-3xl font-black text-gray-900 leading-tight tracking-tight">Global Standings</h3>
              <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.3em] mt-1">Matrix Performance Index</p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-12 h-12 rounded-full hover:bg-white flex items-center justify-center text-gray-400 hover:text-gray-900 transition-all border border-transparent hover:border-gray-200 shadow-sm"
          >
            <i className="fas fa-times text-lg"></i>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 custom-scrollbar">
          {sortedEntries.length === 0 ? (
            <div className="py-20 text-center">
              <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-6 text-gray-300">
                <i className="fas fa-ghost text-3xl"></i>
              </div>
              <p className="font-black text-gray-400 uppercase tracking-widest text-xs">No records found in the matrix yet.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {sortedEntries.map((entry, index) => {
                const isTopThree = index < 3;
                const rankColors = [
                  'bg-amber-400 text-white shadow-amber-200', // Gold
                  'bg-slate-400 text-white shadow-slate-200', // Silver
                  'bg-orange-400 text-white shadow-orange-200', // Bronze
                ];

                return (
                  <div 
                    key={index}
                    className={`group flex items-center gap-6 p-5 rounded-[2rem] border-2 transition-all duration-300 ${
                      index === 0 ? 'bg-indigo-50/30 border-indigo-100' : 'bg-white border-gray-50 hover:border-indigo-100 hover:bg-indigo-50/10'
                    }`}
                  >
                    <div className={`w-12 h-12 shrink-0 rounded-2xl flex items-center justify-center font-black text-lg shadow-lg ${
                      isTopThree ? rankColors[index] : 'bg-gray-100 text-gray-400'
                    }`}>
                      {index + 1}
                    </div>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <h4 className="font-black text-gray-800 truncate uppercase tracking-tight">{entry.userName}</h4>
                        {index === 0 && <i className="fas fa-crown text-amber-400 text-xs animate-bounce"></i>}
                      </div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest truncate">{entry.examTitle}</p>
                    </div>

                    <div className="text-right shrink-0">
                      <div className="text-xl font-black text-indigo-600 leading-none">
                        {entry.percentage}%
                      </div>
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mt-1">
                        {entry.score}/{entry.totalQuestions} Hits
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        <div className="p-8 border-t border-gray-50 bg-gray-50/50 text-center shrink-0">
          <p className="text-[10px] font-black text-gray-400 uppercase tracking-[0.4em]">
            Syncing Real-Time Neural Data
          </p>
        </div>
      </div>
    </div>
  );
};

export default LeaderboardModal;
