
import React from 'react';
import { BrainLogo } from './BrainLogo.tsx';

interface LoadingOverlayProps {
  message?: string;
  progress?: number;
}

const LoadingOverlay: React.FC<LoadingOverlayProps> = ({ message, progress = 0 }) => {
  return (
    <div className="fixed inset-0 z-[100] bg-slate-950 flex flex-col items-center justify-center p-8 overflow-hidden">
      <style>
        {`
          .animate-pulse-slow {
            animation: pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite;
          }
          @keyframes pulse {
            0%, 100% { opacity: 1; transform: scale(1); }
            50% { opacity: 0.7; transform: scale(0.95); }
          }
        `}
      </style>
      
      {/* Abstract glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-indigo-600/10 blur-[100px] rounded-full"></div>

      <div className="w-48 h-48 mb-12 relative animate-pulse-slow">
        <BrainLogo />
      </div>
      
      <div className="text-center space-y-8 max-w-md w-full relative z-10">
        <h2 className="text-4xl font-black text-white tracking-tight uppercase italic">
          AI Examiner <span className="text-[#00ccff]">Active</span>
        </h2>
        
        <div className="bg-slate-900 rounded-full h-3 w-full overflow-hidden border border-slate-800">
          <div 
            className="bg-gradient-to-r from-indigo-600 to-[#00ccff] h-full transition-all duration-700 ease-out"
            style={{ width: `${progress}%` }}
          ></div>
        </div>

        <div className="space-y-2">
          <p className="text-2xl text-indigo-400 font-bold h-8">
            {message || "Generating Test Content..."}
          </p>
          <p className="text-slate-500 font-black text-[10px] tracking-[0.4em] uppercase">
            {progress > 0 ? `${Math.round(progress)}% Complete` : "Initializing Systems"}
          </p>
        </div>
      </div>

      <div className="mt-24 flex flex-col items-center gap-4 text-slate-500 relative z-10">
        <div className="flex gap-4">
          <i className="fas fa-check-circle text-[#00ccff]"></i>
          <span className="text-[10px] font-black uppercase tracking-widest">Verified Exam Patterns</span>
        </div>
        <div className="flex gap-4">
          <i className="fas fa-check-circle text-[#00ccff]"></i>
          <span className="text-[10px] font-black uppercase tracking-widest">Gemini 3 Pro Precision</span>
        </div>
      </div>
    </div>
  );
};

export default LoadingOverlay;
