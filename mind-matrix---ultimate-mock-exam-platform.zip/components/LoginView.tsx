
import React, { useState } from 'react';
import { BrainLogo } from './BrainLogo.tsx';
import { Reveal } from './Reveal.tsx';

interface LoginViewProps {
  onLogin: (name: string, email: string) => void;
}

const LoginView: React.FC<LoginViewProps> = ({ onLogin }) => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !email || !password) return;
    
    setIsSubmitting(true);
    // Simulate a brief authentication delay
    setTimeout(() => {
      onLogin(name, email);
    }, 800);
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col items-center justify-center p-6 relative overflow-hidden">
      {/* Background Decorative Elements */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[800px] h-[500px] bg-indigo-600/10 blur-[150px] rounded-full"></div>
      <div className="absolute bottom-0 right-0 w-[400px] h-[400px] bg-emerald-500/5 blur-[120px] rounded-full"></div>

      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-10">
          <Reveal delay="delay-100" className="w-32 h-32 mx-auto mb-4">
            <BrainLogo />
          </Reveal>
          <Reveal delay="delay-200">
            <h1 className="text-5xl font-black tracking-tight flex items-center justify-center gap-2 mb-2">
              <span className="text-white">MIND</span>
              <span className="text-[#00ccff]">MATRIX</span>
            </h1>
            <p className="text-slate-500 font-bold uppercase tracking-[0.3em] text-[10px]">Neural Assessment Protocol</p>
          </Reveal>
        </div>

        <Reveal delay="delay-300" className="bg-white/5 backdrop-blur-2xl p-10 rounded-[2.5rem] border border-white/10 shadow-2xl">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">User Identity</label>
              <div className="relative group">
                <i className="fas fa-user absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-[#00ccff] transition-colors"></i>
                <input
                  type="text"
                  required
                  placeholder="Enter full name"
                  className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#00ccff]/20 focus:border-[#00ccff]/50 transition-all font-medium"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Neural Link (Email)</label>
              <div className="relative group">
                <i className="fas fa-envelope absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-[#00ccff] transition-colors"></i>
                <input
                  type="email"
                  required
                  placeholder="you@example.com"
                  className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-4 pl-14 pr-6 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#00ccff]/20 focus:border-[#00ccff]/50 transition-all font-medium"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] ml-2">Access Key (Password)</label>
              <div className="relative group">
                <i className="fas fa-lock absolute left-5 top-1/2 -translate-y-1/2 text-slate-500 group-focus-within:text-[#00ccff] transition-colors"></i>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  className="w-full bg-slate-900/50 border border-white/5 rounded-2xl py-4 pl-14 pr-14 text-white placeholder:text-slate-600 focus:outline-none focus:ring-2 focus:ring-[#00ccff]/20 focus:border-[#00ccff]/50 transition-all font-medium"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-5 top-1/2 -translate-y-1/2 text-slate-500 hover:text-[#00ccff] transition-colors"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                >
                  <i className={`fas ${showPassword ? 'fa-eye-slash' : 'fa-eye'}`}></i>
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isSubmitting || !name || !email || !password}
              className="w-full py-5 bg-gradient-to-r from-indigo-600 to-[#00ccff] text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:opacity-90 disabled:opacity-30 transition-all shadow-xl shadow-indigo-600/20 active:scale-[0.98] flex items-center justify-center gap-3 mt-4"
            >
              {isSubmitting ? (
                <>
                  <i className="fas fa-circle-notch animate-spin"></i>
                  Syncing...
                </>
              ) : (
                <>
                  Initialize Access
                  <i className="fas fa-chevron-right text-[10px]"></i>
                </>
              )}
            </button>
          </form>
        </Reveal>

        <Reveal delay="delay-400" className="mt-10 text-center">
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-widest leading-relaxed">
            By proceeding, you agree to the assessment terms<br/>
            & neural data processing protocols.
          </p>
        </Reveal>
      </div>
    </div>
  );
};

export default LoginView;
