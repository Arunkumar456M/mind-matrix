
import React, { useState, useEffect } from 'react';
import { ExamData, UserResponse } from '../types.ts';

interface MockTestViewProps {
  examData: ExamData;
  initialResponses: UserResponse[];
  onFinish: (responses: UserResponse[]) => void;
}

const MockTestView: React.FC<MockTestViewProps> = ({ examData, initialResponses, onFinish }) => {
  const [currentIdx, setCurrentIdx] = useState(0);
  const [responses, setResponses] = useState<UserResponse[]>(initialResponses);
  const [timeLeft, setTimeLeft] = useState(examData.metadata.durationMinutes * 60);
  const [showExitConfirm, setShowExitConfirm] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => {
      setTimeLeft(prev => {
        if (prev <= 0) {
          clearInterval(timer);
          onFinish(responses);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [responses, onFinish]);

  const formatTime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = seconds % 60;
    return `${h > 0 ? h + ':' : ''}${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const currentQuestion = examData.questions[currentIdx];
  const currentResponse = responses[currentIdx];

  const updateResponse = (updates: Partial<UserResponse>) => {
    const newResponses = [...responses];
    newResponses[currentIdx] = { ...newResponses[currentIdx], ...updates };
    setResponses(newResponses);
  };

  const handleOptionSelect = (idx: number) => {
    updateResponse({ selectedOption: idx, status: 'answered' });
  };

  const handleMarkForReview = () => {
    updateResponse({ isMarkedForReview: !currentResponse.isMarkedForReview });
  };

  const navigateTo = (idx: number) => {
    if (responses[currentIdx].status === 'not-visited') {
      const newResponses = [...responses];
      newResponses[currentIdx].status = 'not-answered';
      setResponses(newResponses);
    }
    setCurrentIdx(idx);
  };

  const getStatusColor = (resp: UserResponse) => {
    if (resp.isMarkedForReview) return 'bg-purple-600 text-white';
    if (resp.status === 'answered') return 'bg-emerald-500 text-white';
    if (resp.status === 'not-answered') return 'bg-rose-500 text-white';
    return 'bg-gray-100 text-gray-400';
  };

  return (
    <div className="flex flex-col h-screen overflow-hidden bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b px-8 py-4 flex justify-between items-center shadow-sm z-20">
        <div className="flex items-center gap-4">
          <div className="p-3 bg-indigo-600 rounded-xl text-white shadow-lg shadow-indigo-100">
            <i className="fas fa-edit"></i>
          </div>
          <div>
            <h1 className="text-xl font-black text-gray-900 uppercase tracking-tight leading-none">{examData.metadata.title}</h1>
            <p className="text-xs font-bold text-gray-400 mt-1 uppercase tracking-widest">Live Mock Session</p>
          </div>
        </div>
        <div className="flex items-center gap-8">
          <div className="flex flex-col items-end">
            <span className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">Time Remaining</span>
            <div className={`text-2xl font-black font-mono flex items-center gap-2 ${timeLeft < 300 ? 'text-rose-600 animate-pulse' : 'text-indigo-600'}`}>
              <i className="fas fa-hourglass-half text-sm"></i>
              {formatTime(timeLeft)}
            </div>
          </div>
          <button 
            onClick={() => setShowExitConfirm(true)}
            className="px-8 py-3 bg-rose-50 text-rose-600 hover:bg-rose-600 hover:text-white rounded-xl font-bold transition-all border border-rose-100"
          >
            End Test
          </button>
        </div>
      </header>

      <div className="flex-1 flex overflow-hidden">
        {/* Main Question Area */}
        <main className="flex-1 overflow-y-auto p-12 custom-scrollbar">
          <div className="max-w-4xl mx-auto">
            <div className="bg-white rounded-3xl shadow-2xl shadow-indigo-50 border border-gray-100 overflow-hidden">
              <div className="bg-gray-50/50 px-10 py-6 border-b flex justify-between items-center">
                <div className="flex items-center gap-4">
                  <span className="w-10 h-10 bg-indigo-600 text-white rounded-full flex items-center justify-center font-black">
                    {currentIdx + 1}
                  </span>
                  <div className="flex flex-col">
                    <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Section</span>
                    <span className="text-sm font-black text-gray-700">{currentQuestion.section}</span>
                  </div>
                </div>
                <div className="flex gap-2">
                   <span className="px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest bg-white border text-gray-500">
                    {currentQuestion.marks} Marks
                  </span>
                  <span className={`px-4 py-1.5 rounded-full text-[10px] font-black uppercase tracking-widest ${
                    currentQuestion.difficulty === 'Easy' ? 'bg-emerald-100 text-emerald-700' :
                    currentQuestion.difficulty === 'Medium' ? 'bg-amber-100 text-amber-700' : 'bg-rose-100 text-rose-700'
                  }`}>
                    {currentQuestion.difficulty}
                  </span>
                </div>
              </div>
              
              <div className="p-12">
                <p className="text-2xl leading-relaxed text-gray-800 mb-10 font-bold">
                  {currentQuestion.text}
                </p>

                <div className="grid gap-4">
                  {currentQuestion.options.map((opt, i) => (
                    <button
                      key={i}
                      onClick={() => handleOptionSelect(i)}
                      className={`w-full text-left p-6 rounded-2xl border-2 transition-all flex items-center gap-6 group relative overflow-hidden ${
                        currentResponse.selectedOption === i 
                          ? 'border-indigo-600 bg-indigo-50/50 shadow-inner' 
                          : 'border-gray-100 hover:border-indigo-200 hover:bg-white bg-gray-50/30'
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-xl flex items-center justify-center font-black border-2 transition-colors ${
                         currentResponse.selectedOption === i 
                          ? 'bg-indigo-600 text-white border-indigo-600' 
                          : 'bg-white text-gray-400 border-gray-200 group-hover:border-indigo-300'
                      }`}>
                        {String.fromCharCode(65 + i)}
                      </div>
                      <span className="text-lg font-bold text-gray-700">{opt}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="px-10 py-8 bg-gray-50/50 border-t flex justify-between items-center">
                <div className="flex gap-4">
                  <button 
                    onClick={() => updateResponse({ selectedOption: null, status: 'not-answered' })}
                    className="text-gray-400 hover:text-rose-600 font-black uppercase tracking-widest text-[11px] px-6 py-3 rounded-xl border border-transparent hover:border-rose-100 transition-all"
                  >
                    Clear Response
                  </button>
                  <button 
                    onClick={handleMarkForReview}
                    className={`px-6 py-3 rounded-xl border-2 transition-all font-black text-[11px] uppercase tracking-widest ${
                      currentResponse.isMarkedForReview 
                        ? 'bg-purple-600 border-purple-600 text-white shadow-lg shadow-purple-100' 
                        : 'border-gray-200 text-gray-500 hover:border-purple-300 hover:text-purple-600'
                    }`}
                  >
                    <i className="fas fa-flag mr-2"></i>
                    {currentResponse.isMarkedForReview ? 'Marked for Review' : 'Review Later'}
                  </button>
                </div>
                <div className="flex gap-4">
                  <button 
                    disabled={currentIdx === 0}
                    onClick={() => navigateTo(currentIdx - 1)}
                    className="px-8 py-4 rounded-xl bg-white border-2 border-gray-200 text-gray-700 hover:bg-gray-100 disabled:opacity-30 transition-all font-black text-xs uppercase"
                  >
                    Back
                  </button>
                  <button 
                    onClick={() => currentIdx < examData.questions.length - 1 ? navigateTo(currentIdx + 1) : setShowExitConfirm(true)}
                    className="px-10 py-4 rounded-xl bg-indigo-600 text-white hover:bg-indigo-700 shadow-xl shadow-indigo-200 transition-all font-black text-xs uppercase"
                  >
                    {currentIdx < examData.questions.length - 1 ? 'Save & Continue' : 'Finish Test'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </main>

        {/* Question Palette Sidebar */}
        <aside className="w-96 border-l bg-white flex flex-col z-10 shadow-2xl">
          <div className="p-8 border-b bg-gray-50/50">
            <h2 className="text-xs font-black text-gray-400 uppercase tracking-[0.2em] mb-6">Question Navigator</h2>
            <div className="grid grid-cols-5 gap-2 max-h-[400px] overflow-y-auto pr-2 custom-scrollbar">
              {responses.map((resp, i) => (
                <button
                  key={i}
                  onClick={() => navigateTo(i)}
                  className={`aspect-square rounded-xl flex items-center justify-center font-black text-xs transition-all transform hover:scale-105 ${
                    i === currentIdx ? 'ring-4 ring-indigo-200 shadow-lg scale-110 z-10 border-2 border-indigo-600' : ''
                  } ${getStatusColor(resp)}`}
                >
                  {i + 1}
                </button>
              ))}
            </div>
          </div>

          <div className="p-8 space-y-8 flex-1 overflow-y-auto custom-scrollbar">
            <div>
              <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Exam Statistics</h3>
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
                  <div className="text-2xl font-black text-emerald-700">{responses.filter(r => r.status === 'answered').length}</div>
                  <div className="text-[10px] uppercase font-black text-emerald-500">Solved</div>
                </div>
                <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
                  <div className="text-2xl font-black text-rose-700">{responses.filter(r => r.status === 'not-answered').length}</div>
                  <div className="text-[10px] uppercase font-black text-rose-500">Skipped</div>
                </div>
                <div className="p-4 bg-purple-50 rounded-2xl border border-purple-100">
                  <div className="text-2xl font-black text-purple-700">{responses.filter(r => r.isMarkedForReview).length}</div>
                  <div className="text-[10px] uppercase font-black text-purple-500">Review</div>
                </div>
                <div className="p-4 bg-gray-50 rounded-2xl border border-gray-100">
                  <div className="text-2xl font-black text-gray-700">{responses.filter(r => r.status === 'not-visited').length}</div>
                  <div className="text-[10px] uppercase font-black text-gray-400">Untouched</div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-black text-gray-400 uppercase tracking-widest mb-4">Exam Info</h3>
              <div className="bg-indigo-50/30 rounded-2xl p-6 border border-indigo-100/50 space-y-4">
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-500">Total Questions</span>
                  <span className="text-sm font-black text-indigo-700">{examData.questions.length}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-xs font-bold text-gray-500">Max Marks</span>
                  <span className="text-sm font-black text-indigo-700">{examData.metadata.totalMarks}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="p-8 border-t bg-gray-50 flex items-center gap-4">
             <i className="fas fa-shield-alt text-indigo-400"></i>
             <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest leading-relaxed">
              Anti-cheat enabled. Test duration is monitored by AI.
             </p>
          </div>
        </aside>
      </div>

      {/* Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-gray-900/60 backdrop-blur-md flex items-center justify-center z-[100] p-6">
          <div className="bg-white rounded-[40px] p-12 max-w-xl w-full shadow-[0_0_100px_rgba(0,0,0,0.2)]">
            <div className="w-24 h-24 bg-rose-100 text-rose-600 rounded-3xl flex items-center justify-center text-4xl mb-8">
              <i className="fas fa-sign-out-alt"></i>
            </div>
            <h3 className="text-4xl font-black text-gray-900 mb-4 tracking-tight">Ready to Submit?</h3>
            <p className="text-xl text-gray-500 mb-10 leading-relaxed font-medium">
              You've answered <span className="text-indigo-600 font-bold">{responses.filter(r => r.status === 'answered').length}</span> questions. Once submitted, you cannot modify your responses.
            </p>
            <div className="flex gap-6">
              <button 
                onClick={() => setShowExitConfirm(false)}
                className="flex-1 py-5 font-black text-gray-400 hover:text-gray-900 uppercase tracking-widest text-xs transition-all"
              >
                Continue Test
              </button>
              <button 
                onClick={() => onFinish(responses)}
                className="flex-1 py-5 bg-indigo-600 text-white rounded-3xl font-black uppercase tracking-widest text-xs hover:bg-indigo-700 shadow-2xl shadow-indigo-100 transition-all"
              >
                Submit Exam
              </button>
            </div>
          </div>
        </div>
      )}

      <style>
        {`
          .custom-scrollbar::-webkit-scrollbar {
            width: 6px;
          }
          .custom-scrollbar::-webkit-scrollbar-track {
            background: transparent;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #e2e8f0;
            border-radius: 10px;
          }
          .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #cbd5e1;
          }
        `}
      </style>
    </div>
  );
};

export default MockTestView;
