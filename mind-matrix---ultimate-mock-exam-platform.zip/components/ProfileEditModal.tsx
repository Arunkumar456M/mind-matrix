
import React, { useState, useEffect } from 'react';
import { User, LeaderboardEntry } from '../types.ts';

interface ProfileEditModalProps {
  user: User;
  onClose: () => void;
  onSave: (updatedUser: User) => void;
}

const LEADERBOARD_KEY = 'mindmatrix_leaderboard_v1';

const ProfileEditModal: React.FC<ProfileEditModalProps> = ({ user, onClose, onSave }) => {
  const [activeTab, setActiveTab] = useState<'info' | 'history'>('info');
  const [formData, setFormData] = useState<User>({
    name: user.name,
    email: user.email,
    bio: user.bio || '',
    location: user.location || '',
  });
  const [userHistory, setUserHistory] = useState<LeaderboardEntry[]>([]);

  useEffect(() => {
    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    if (savedLeaderboard) {
      try {
        const allEntries: LeaderboardEntry[] = JSON.parse(savedLeaderboard);
        const filtered = allEntries
          .filter(e => e.userEmail === user.email)
          .sort((a, b) => b.timestamp - a.timestamp);
        setUserHistory(filtered);
      } catch (e) {
        console.error("History parse error", e);
      }
    }
  }, [user.email]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/80 backdrop-blur-xl animate-in fade-in duration-300">
      <div className="bg-white rounded-[2.5rem] w-full max-w-xl shadow-2xl overflow-hidden animate-in zoom-in-95 duration-300 flex flex-col max-h-[90vh]">
        <div className="p-10 border-b border-gray-100 bg-gray-50/50 flex justify-between items-center shrink-0">
          <div>
            <h3 className="text-2xl font-black text-gray-900 leading-tight">User Matrix</h3>
            <p className="text-[10px] font-black text-gray-400 uppercase tracking-widest mt-1">Identity & Performance Records</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 rounded-full hover:bg-white flex items-center justify-center text-gray-400 hover:text-gray-900 transition-all border border-transparent hover:border-gray-200"
          >
            <i className="fas fa-times"></i>
          </button>
        </div>

        <div className="flex border-b border-gray-100 shrink-0">
          <button 
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${
              activeTab === 'info' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            Profile Info
          </button>
          <button 
            onClick={() => setActiveTab('history')}
            className={`flex-1 py-4 text-[10px] font-black uppercase tracking-widest transition-all ${
              activeTab === 'history' ? 'text-indigo-600 border-b-2 border-indigo-600 bg-indigo-50/30' : 'text-gray-400 hover:text-gray-600'
            }`}
          >
            My Results ({userHistory.length})
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-10 custom-scrollbar">
          {activeTab === 'info' ? (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="space-y-4">
                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Full Name</label>
                  <input
                    type="text"
                    required
                    className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all font-bold text-gray-700"
                    value={formData.name}
                    onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Email Address</label>
                  <input
                    type="email"
                    required
                    readOnly
                    className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50/50 text-gray-400 cursor-not-allowed font-bold"
                    value={formData.email}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Location</label>
                  <input
                    type="text"
                    placeholder="e.g. San Francisco, CA"
                    className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all font-bold text-gray-700"
                    value={formData.location}
                    onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-black text-gray-400 uppercase tracking-[0.2em] mb-2">Bio / Aspirations</label>
                  <textarea
                    rows={3}
                    placeholder="Tell us about your learning goals..."
                    className="w-full p-4 border-2 border-gray-50 rounded-2xl bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-100 focus:border-indigo-500 outline-none transition-all font-bold text-gray-700 resize-none"
                    value={formData.bio}
                    onChange={(e) => setFormData({ ...formData, bio: e.target.value })}
                  />
                </div>
              </div>

              <div className="flex gap-4 pt-4">
                <button
                  type="button"
                  onClick={onClose}
                  className="flex-1 py-4 bg-gray-100 text-gray-500 rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-gray-200 transition-all"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex-1 py-4 bg-indigo-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs hover:bg-indigo-700 shadow-xl shadow-indigo-100 transition-all"
                >
                  Save Changes
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-4">
              {userHistory.length === 0 ? (
                <div className="py-12 text-center">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mx-auto mb-4 text-gray-300">
                    <i className="fas fa-file-lines text-2xl"></i>
                  </div>
                  <p className="text-xs font-bold text-gray-400 uppercase tracking-widest">No matrix logs recorded yet.</p>
                </div>
              ) : (
                userHistory.map((entry, idx) => (
                  <div key={idx} className="bg-gray-50 border border-gray-100 p-5 rounded-2xl flex justify-between items-center group hover:bg-white hover:border-indigo-100 transition-all">
                    <div>
                      <h4 className="font-black text-gray-800 uppercase text-xs tracking-tight">{entry.examTitle}</h4>
                      <p className="text-[10px] font-bold text-gray-400 mt-1 uppercase">
                        {new Date(entry.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-black text-indigo-600">{entry.percentage}%</div>
                      <div className="text-[9px] font-black text-gray-400 uppercase tracking-widest">{entry.score}/{entry.totalQuestions} Hits</div>
                    </div>
                  </div>
                ))
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProfileEditModal;
