
import React, { useEffect } from 'react';
import { ExamData, UserResponse, LeaderboardEntry } from '../types.ts';

interface ResultViewProps {
  examData: ExamData;
  userResponses: UserResponse[];
  onRestart: () => void;
  userName: string;
  userEmail: string;
}

const LEADERBOARD_KEY = 'mindmatrix_leaderboard_v1';

const ResultView: React.FC<ResultViewProps> = ({ examData, userResponses, onRestart, userName, userEmail }) => {
  const calculateScore = () => {
    let score = 0;
    userResponses.forEach((resp, idx) => {
      if (resp.selectedOption === examData.questions[idx].correctAnswer) {
        score++;
      }
    });
    return score;
  };

  const score = calculateScore();
  const percentage = Math.round((score / examData.questions.length) * 100);

  useEffect(() => {
    // Save to global leaderboard (mocking server-side sync with localstorage)
    const entry: LeaderboardEntry = {
      userName,
      userEmail,
      examTitle: examData.metadata.title,
      score,
      totalQuestions: examData.questions.length,
      percentage,
      timestamp: Date.now()
    };

    const savedLeaderboard = localStorage.getItem(LEADERBOARD_KEY);
    let leaderboard: LeaderboardEntry[] = [];
    if (savedLeaderboard) {
      try {
        leaderboard = JSON.parse(savedLeaderboard);
      } catch (e) {
        console.error("Leaderboard parse error", e);
      }
    }
    
    leaderboard.push(entry);
    // Keep only top 100 entries for efficiency
    leaderboard.sort((a, b) => b.percentage - a.percentage).slice(0, 100);
    localStorage.setItem(LEADERBOARD_KEY, JSON.stringify(leaderboard));
  }, [examData, score, percentage, userName, userEmail]);

  return (
    <div className="max-w-5xl mx-auto py-12 px-4">
      <div className="bg-white rounded-3xl shadow-xl overflow-hidden border border-gray-100">
        <div className="bg-indigo-600 p-12 text-center text-white relative">
          <div className="absolute top-8 left-8">
            <button onClick={onRestart} className="text-white/80 hover:text-white flex items-center gap-2 font-medium">
              <i className="fas fa-arrow-left"></i> Home
            </button>
          </div>
          <h2 className="text-4xl font-bold mb-4">Exam Completed!</h2>
          <div className="inline-block relative">
            <svg className="w-48 h-48 transform -rotate-90">
              <circle
                cx="96"
                cy="96"
                r="80"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                className="text-white/20"
              />
              <circle
                cx="96"
                cy="96"
                r="80"
                stroke="currentColor"
                strokeWidth="12"
                fill="transparent"
                strokeDasharray={502.4}
                strokeDashoffset={502.4 - (502.4 * percentage) / 100}
                className="text-white transition-all duration-1000"
              />
            </svg>
            <div className="absolute inset-0 flex flex-col items-center justify-center">
              <span className="text-5xl font-black">{percentage}%</span>
              <span className="text-sm font-bold text-white/60">ACCURACY</span>
            </div>
          </div>
          <div className="mt-8 flex justify-center gap-12">
            <div className="text-center">
              <div className="text-3xl font-bold">{score} / {examData.questions.length}</div>
              <div className="text-xs font-bold text-white/60 tracking-widest">SCORE</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold">{userResponses.filter(r => r.selectedOption !== null).length}</div>
              <div className="text-xs font-bold text-white/60 tracking-widest">ATTEMPTED</div>
            </div>
          </div>
        </div>

        <div className="p-8">
          <h3 className="text-2xl font-bold mb-8 flex items-center gap-3">
            <i className="fas fa-list-check text-indigo-500"></i>
            Detailed Review
          </h3>
          <div className="space-y-6">
            {examData.questions.map((q, i) => {
              const userResp = userResponses[i];
              const isCorrect = userResp.selectedOption === q.correctAnswer;
              
              return (
                <div key={q.id} className={`p-6 rounded-2xl border-2 transition-all ${
                  isCorrect ? 'border-green-100 bg-green-50/30' : 
                  userResp.selectedOption === null ? 'border-gray-100 bg-gray-50' : 'border-red-100 bg-red-50/30'
                }`}>
                  <div className="flex justify-between items-start mb-4">
                    <span className="font-bold text-gray-400">Q{i + 1}</span>
                    <span className={`px-3 py-1 rounded-full text-xs font-bold ${
                      isCorrect ? 'bg-green-100 text-green-700' : 
                      userResp.selectedOption === null ? 'bg-gray-200 text-gray-500' : 'bg-red-100 text-red-700'
                    }`}>
                      {isCorrect ? 'Correct' : userResp.selectedOption === null ? 'Not Attempted' : 'Incorrect'}
                    </span>
                  </div>
                  <p className="text-lg font-medium text-gray-800 mb-6">{q.text}</p>
                  
                  <div className="grid md:grid-cols-2 gap-3 mb-6">
                    {q.options.map((opt, optIdx) => (
                      <div key={optIdx} className={`p-3 rounded-xl border flex items-center gap-3 ${
                        optIdx === q.correctAnswer ? 'border-green-500 bg-green-100/50 text-green-800 font-bold' :
                        optIdx === userResp.selectedOption && !isCorrect ? 'border-red-500 bg-red-100 text-red-800 font-bold' :
                        'border-gray-200 bg-white'
                      }`}>
                        <div className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold ${
                           optIdx === q.correctAnswer ? 'bg-green-500 text-white' :
                           optIdx === userResp.selectedOption && !isCorrect ? 'bg-red-500 text-white' : 'bg-gray-100 text-gray-400'
                        }`}>
                          {String.fromCharCode(65 + optIdx)}
                        </div>
                        {opt}
                      </div>
                    ))}
                  </div>

                  <div className="bg-white/60 p-4 rounded-xl border border-dashed border-gray-300">
                    <h4 className="text-sm font-bold text-gray-500 mb-2">EXPLANATION</h4>
                    <p className="text-gray-600 leading-relaxed italic">{q.explanation}</p>
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-12 flex justify-center pb-8">
            <button 
              onClick={onRestart}
              className="px-12 py-5 bg-indigo-600 text-white rounded-2xl font-bold hover:bg-indigo-700 shadow-2xl shadow-indigo-200 transition-all flex items-center gap-3"
            >
              <i className="fas fa-rotate-right"></i>
              Take Another Test
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ResultView;
