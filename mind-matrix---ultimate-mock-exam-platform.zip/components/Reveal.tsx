
import React, { useState, useEffect, useRef } from 'react';

export interface RevealProps {
  children: React.ReactNode;
  className?: string;
  animation?: 'reveal' | 'reveal-left' | 'reveal-right';
  delay?: string;
}

export const Reveal: React.FC<RevealProps> = ({ children, className = "", animation = 'reveal', delay = "" }) => {
  const [isVisible, setIsVisible] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.unobserve(entry.target);
        }
      },
      { threshold: 0.1 }
    );

    if (ref.current) {
      observer.observe(ref.current);
    }

    return () => observer.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      className={`${animation} ${isVisible ? 'reveal-visible' : ''} ${delay} ${className}`}
    >
      {children}
    </div>
  );
};
