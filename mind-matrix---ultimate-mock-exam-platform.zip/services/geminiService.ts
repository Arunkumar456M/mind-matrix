
import { GoogleGenAI, Type } from "@google/genai";
// Fixed: Added ExamData to the imports to resolve "Cannot find name 'ExamData'" error on line 132
import { ExamMetadata, Question, ExamData } from "../types.ts";

const METADATA_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    title: { type: Type.STRING },
    subject: { type: Type.STRING },
    totalQuestions: { type: Type.INTEGER },
    durationMinutes: { type: Type.INTEGER },
    totalMarks: { type: Type.INTEGER },
    sections: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING },
          count: { type: Type.INTEGER }
        },
        required: ["name", "count"]
      }
    },
    markingScheme: { type: Type.STRING }
  },
  required: ["title", "subject", "totalQuestions", "durationMinutes", "totalMarks", "sections"]
};

const BATCH_SCHEMA = {
  type: Type.OBJECT,
  properties: {
    batchNumber: { type: Type.INTEGER },
    questions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.INTEGER },
          text: { type: Type.STRING },
          options: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          correctAnswer: { type: Type.INTEGER },
          explanation: { type: Type.STRING },
          section: { type: Type.STRING },
          difficulty: { type: Type.STRING, enum: ['Easy', 'Medium', 'Hard'] },
          marks: { type: Type.NUMBER },
          estimatedTimeSeconds: { type: Type.INTEGER }
        },
        required: ["id", "text", "options", "correctAnswer", "explanation", "section", "difficulty", "marks", "estimatedTimeSeconds"]
      }
    }
  },
  required: ["batchNumber", "questions"]
};

export const getExamMetadata = async (examName: string, subject: string, difficulty: string): Promise<ExamMetadata> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Step 1: Search for the actual pattern using Google Search Grounding
  // Per rules, Search grounded output might not be JSON, so we treat it as text context first.
  const searchPrompt = `Find the official exam pattern for "${examName}" specifically for the "${subject}" core subject. 
  Determine: 
  1. Total number of questions
  2. Total duration in minutes
  3. Subject-wise sections and question distribution
  4. Marking scheme
  Use reliable sources like official sites or testbook.com/syllabus-exam-pattern.`;

  // Refactored: Using string contents for simple text prompts as recommended in SDK guidelines
  const searchResponse = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: searchPrompt,
    config: {
      tools: [{ googleSearch: {} }],
    },
  });

  const searchContext = searchResponse.text;

  // Step 2: Convert the searched pattern info into the structured JSON schema
  const formatPrompt = `Based on the following search context about the "${examName}" exam pattern for "${subject}", format it into valid JSON.
  Context: ${searchContext}
  
  Target Difficulty for generation: ${difficulty}.
  Return valid JSON matching the metadata schema.`;

  const finalResponse = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: formatPrompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: METADATA_SCHEMA as any,
    },
  });

  return JSON.parse(finalResponse.text || '{}');
};

export const generateQuestionBatch = async (
  examName: string, 
  subject: string,
  metadata: ExamMetadata, 
  startIndex: number, 
  batchSize: number,
  existingQuestionsCount: number
): Promise<{ batchNumber: number, questions: Question[] }> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const batchNum = Math.floor(startIndex / batchSize) + 1;
  
  const prompt = `You are an intelligent Exam Mock Test Generator. 
  Generate Batch #${batchNum} for the "${examName}" exam, core subject "${subject}".
  Pattern: ${JSON.stringify(metadata)}
  
  Instructions:
  1. Generate questions from ID ${startIndex + 1} to ${Math.min(startIndex + batchSize, metadata.totalQuestions)}.
  2. Questions must strictly match the conceptual depth and complexity of real papers.
  3. Return strictly as JSON matching the batch schema.`;

  // Refactored: simplified contents for generateContent call
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: prompt,
    config: {
      responseMimeType: "application/json",
      responseSchema: BATCH_SCHEMA as any,
    },
  });

  return JSON.parse(response.text || '{}');
};

// Fixed: The function signature now correctly identifies ExamData after importing it
export const generateExamFromBase64 = async (base64: string, mimeType: string): Promise<ExamData> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    // Refactored: Using the correct { parts: [...] } structure for multimodal contents
    contents: {
      parts: [
        { inlineData: { data: base64, mimeType } },
        { text: "Analyze this document and generate a full mock test based on its content. Max 40 questions. Format as JSON with 'metadata' and 'questions' array." }
      ]
    },
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          metadata: METADATA_SCHEMA,
          questions: {
            type: Type.ARRAY,
            items: BATCH_SCHEMA.properties.questions.items
          }
        }
      } as any,
    }
  });
  return JSON.parse(response.text || '{}');
};
