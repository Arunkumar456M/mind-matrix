
export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number; // index of options
  explanation: string;
  section: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  marks: number;
  estimatedTimeSeconds?: number;
}

export interface ExamMetadata {
  title: string;
  subject: string;
  totalQuestions: number;
  durationMinutes: number;
  totalMarks: number;
  sections: { name: string; count: number }[];
  markingScheme?: string;
}

export interface ExamData {
  metadata: ExamMetadata;
  questions: Question[];
}

export interface UserResponse {
  questionId: number;
  selectedOption: number | null;
  isMarkedForReview: boolean;
  status: 'answered' | 'not-answered' | 'not-visited' | 'marked';
}

export interface User {
  name: string;
  email: string;
  bio?: string;
  location?: string;
}

export interface LeaderboardEntry {
  userName: string;
  userEmail: string;
  examTitle: string;
  score: number;
  totalQuestions: number;
  percentage: number;
  timestamp: number;
}

export enum AppState {
  LOGIN = 'LOGIN',
  HOME = 'HOME',
  LOADING = 'LOADING',
  TEST = 'TEST',
  RESULTS = 'RESULTS'
}
